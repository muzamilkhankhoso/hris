<?php
use App\Helpers\CommonHelper;
use App\Helpers\HrHelper;
use App\Models\MenuPrivileges;
use App\Models\Menu;

$accType = Auth::user()->acc_type;
if($accType == 'client'){$m = $_GET['m'];}else{$m = Auth::user()->company_id;}

$user_rights = MenuPrivileges::where([['emp_id','=',Auth::user()->emp_id]]);

$crud_permission='';
if($user_rights->count() > 0):
    $main_modules = explode(",",$user_rights->value('main_modules'));
    $submenu_ids  = explode(",",$user_rights->value('submenu_id'));
	$crud_rights  = explode(",",$user_rights->value('crud_rights'));
    $companyList= $user_rights->value('company_list');

else:
	echo "Account Type:".$accType;
    echo 'Insufficient Menu Privileges'."<br>";
    echo "<a href='".url('/logout')."'>Logout</a>";
endif;  
  

     
   

?>  

<header>
	<div class="header-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 pull-right">
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown user-name-drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">{{ Auth::user()->name[0] }}</a>
							<div class="account-information dropdown-menu">
								<div class="account-inner">
									<div class="title">
										<span>{{ Auth::user()->name[0] }}</span>
									</div>
									<div class="main-heading">
										<h5>{{ Auth::user()->name }}</h5>
										<p>Bridging the Future of Industry.</p>
										
									</div>
								</div>
								<div class="account-footer">
									 <a href="{{ url('/users/editUserProfile?m=').Input::get('m') }}" class="btn link-accounts contact_support">
                                        <span class="glyphicon glyphicon-edit"></span>&nbsp;Change Password</a>
									<a href="{{ url('/logout') }}" class="btn link-accounts sign_out">Sign out</a>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 hideforPassChange">
					<?php
					if(array_search('User_Dashboard',$crud_rights) !== false):
						$link = '/dc/userDashboard';
					elseif(array_search('HR_Dashboard',$crud_rights) !== false):
						$link = '/dc/hrDashboard';
					elseif(array_search('Finance_Dashboard',$crud_rights) !== false):
						$link = '/dc/financeDashboard';
					else:
						$link = '/d';
					endif; ?>
					<a href="{{url($link.'?m='.Input::get('m').'') }}" class="btn btn-dashboard"><i class="glyphicon glyphicon-home" aria-hidden="true"></i> Dashboard</a>
				</div>
			</div>
		</div>
	</div>
</header>
<div class="container-fluid">
	<nav class="navbar navbar-fixed-top erp-menus" style="position: absolute;">
		<div class="navbar-header">
			<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
		</div>
		<div class="collapse navbar-collapse js-navbar-collapse">
			<!--Company List Begin-->

			<?php if(Input::get('m') != ''): ?>
			<!--Company List End-->
            <?php

            $MainMenuTitles = DB::table('main_menu_title')->select(['main_menu_id','id'])->where([['menu_type','=',1],['status','=',1]])->groupBy('main_menu_id')->get();

            $counter = 1;
			foreach($main_modules as $row){
			if(in_array($row,$main_modules)):
			 $main_menu_id = DB::table('main_menu_title')->select('main_menu_id')->where([['id','=',$row]])->value('main_menu_id');
			?>

			<ul class="nav navbar-nav hideforPassChange">
				<li class="dropdown mega-dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-user" aria-hidden="true"></i> <?php echo $main_menu_id;?></a>
					<ul class="dropdown-menu mega-dropdown-menu row">

                        <?php


						$main_query = DB::table('menu')
							->join('main_menu_title','main_menu_title.id','=','menu.m_parent_code')
							->select('menu.m_main_title','main_menu_title.id')
							->whereIn('menu.id',$submenu_ids)
							->where('main_menu_title.main_menu_id','=',$main_menu_id)
							->where('menu.status','=',1)
							->where('main_menu_title.status','=',1)
							->distinct()
							->get();
                        $MainMenuTitlesSub = DB::table('main_menu_title')->select(['main_menu_id','title','title_id','id'])->where([['main_menu_id','=',$main_menu_id],['status','=',1]])->get(); 
						
                        foreach($main_query as $row1){
                        ?>     
						<li class="col-sm-2">  
							<ul> 
								<li class="dropdown-header"><?php echo $row1->m_main_title; ?> </li>
                                <?php
                                $data = DB::table('menu')->select(['m_type','name','m_controller_name','m_main_title','id','m_parent_code'])->where([['m_parent_code','=',$row1->id],['page_type', '=', 1]])->get();

                                foreach($data as $dataValue){
                                $MakeUrl = url(''.$dataValue->m_controller_name.'');

                                if(in_array($dataValue->id,$submenu_ids)): ?>

								<li><a href="<?php echo url(''.$dataValue->m_controller_name.'?pageType='.$dataValue->m_type.'&&parentCode='.$dataValue->m_parent_code.'&&m='.Input::get('m').'#Innovative')?>"><i class="glyphicon glyphicon-plus-sign"></i> <?php echo $dataValue->name;?></a></li>
                                <?php

                                endif;
                                } ?>

							</ul>
						</li>
                        <?php } ?>
					</ul>
				</li>
			</ul>
            <?php
            endif;
            }
            ?>
 <?php endif; ?>




		</div>
		<!-- /.nav-collapse -->
	</nav>
</div>

<br />

<!--For Demo Only (End Removable) -->
<input type="hidden" id="baseUrl" value="<?php echo url('/') ?>">
<input type="hidden" id="emp_id" value="<?php echo Auth::user()->emp_id ?>">


<!-- MENU SECTION END-->