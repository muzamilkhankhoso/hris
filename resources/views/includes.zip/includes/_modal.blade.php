{{--<div id="right-modal"  class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">--}}
    {{--<div class="modal-dialog modal-sm modal-right">--}}
        {{--<div class="modal-content">--}}
            {{--<div class="modal-header border-0">--}}
                {{--<h4 class="modalTitle modal-title" id="info-header-modalLabel"></h4>--}}
                {{--<button type="button" class="close" data-dismiss="modal"--}}
                        {{--aria-hidden="true">×</button>--}}
            {{--</div>--}}
            {{--<div class="modal-body">--}}
                {{--<div class="text-center">--}}
                    {{--<h4 class="mt-0">Text in a modal</h4>--}}
                    {{--<p>Duis mollis, est non commodo luctus, nisi erat porttitor ligula.--}}
                    {{--</p>--}}
                    {{--<button type="button" class="btn btn-danger btn-sm"--}}
                            {{--data-dismiss="modal">Close</button>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div><!-- /.modal-content -->--}}
    {{--</div><!-- /.modal-dialog -->--}}
{{--</div><!-- /.modal -->--}}






<div id="showDetailModelTwoParamerter" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">

    <div class="modal-dialog modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header modal-colored-header bg-primary" style="height: 80px;">
                <div class="text-center mt-2 mb-3"></div>
                <div class="text-center mt-3 mb-4">
                    <h3 style="font-weight: bolder;" class="modalTitle" aria-hidden="true"></h3>
                </div>
                <button class="btn btn-sm btn-danger" type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">X</button>
            </div>
            <div class="modal-body">
                <div class="text-center">

                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>