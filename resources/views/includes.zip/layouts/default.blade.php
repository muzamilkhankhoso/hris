<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ URL::asset('assets/images/favicon.png') }}">
    <title>{{ env('APP_NAME') }}</title>
    <!-- Custom CSS -->
    <link href="{{ URL::asset('assets/extra-libs/c3/c3.min.css') }}" rel="stylesheet">

    <link href="{{ URL::asset('assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css') }}" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="{{ URL::asset('assets/dist/css/style.min.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('assets/custom/css/custom.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ URL::asset('assets/dist/css/select2.min.css') }}">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="{{ URL::asset('assets/libs/jquery/dist/jquery.min.js') }}"></script>
    <link rel="stylesheet" href="{{ URL::asset('assets/dist/css/select2.min.css') }}">
    <style>
    .has-search .form-control {
    padding-left: 2.375rem;
}

.has-search .form-control-feedback {
    position: absolute;
    z-index: 2;
    display: block;
    width: 2.375rem;
    height: 2.375rem;
    line-height: 2.375rem;
    text-align: center;
    pointer-events: none;
    color: #aaa;
}
    .card-body {

        border-top: 4px solid #5f76e8;
    }

</style>

</head>
<body>
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
@include('includes._clientNavigation')
<div class="container-fluid" id="mainSFContent">
<input type="hidden" id="m" value="{{ Input::get('m') }}">
    <input type="hidden" id="baseUrl" value="{{ url('/') }}">
    <input type="hidden" id="employeeid" value="{{ \Illuminate\Support\Facades\Auth::user()->emp_id }}">
    <br>
	@yield('content')

</div>
@include('includes._modal')
@include('includes._footer')


<script src="{{ URL::asset('assets/libs/popper.js/dist/umd/popper.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<!-- apps -->
<!-- apps -->
<script src="{{ URL::asset('assets/dist/js/app-style-switcher.js') }}"></script>
<script src="{{ URL::asset('assets/dist/js/feather.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js') }}"></script>
<script src="{{ URL::asset('assets/dist/js/sidebarmenu.js') }}"></script>
<!--Custom JavaScript -->
<script src="{{ URL::asset('assets/dist/js/custom.min.js') }}"></script>
<!--This page JavaScript -->
<script src="{{ URL::asset('assets/extra-libs/c3/d3.min.js') }}"></script>
<script src="{{ URL::asset('assets/extra-libs/c3/c3.min.js') }}"></script>

<script src="{{ URL::asset('assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js') }}"></script>
<script src="{{ URL::asset('assets/dist/js/pages/dashboards/dashboard1.min.js') }}"></script>

<script src="{{ url('assets//dist/js/dataTables/jquery.dataTables.js') }}"> </script>
<script src="{{ URL::asset('assets/custom/js/dashboard.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/modal.js') }}"></script>
<script src="{{ URL::asset('assets/dist/js/select2.min.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/allowances.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/attendances.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/employees.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/payroll.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/users.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/deductions.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/advanceSalary.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/customHrFunction.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/loanRequests.js') }}"></script>
<script src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>
<script src="{{ URL::asset('assets/custom/js/bonus.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/custom.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/leaveApplications.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/workingHourPolicies.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/holidays.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/exitClearances.js') }}"></script>
<script src="{{ URL::asset('assets/custom/js/promotions.js') }}"></script>
</body>